<?php
/**
 * Fallback index — uses parent BeTheme layout for non-front pages.
 *
 * @package Betheme_Fix4u
 */

if ( locate_template( array( 'index.php' ), false, false ) && get_template_directory() !== get_stylesheet_directory() ) {
	// Load parent index for blog/other views.
	include get_template_directory() . '/index.php';
	return;
}

get_header();
?>
<main class="container" style="padding:140px 0 80px;">
	<?php if ( have_posts() ) : ?>
		<?php while ( have_posts() ) : ?>
			<?php the_post(); ?>
			<article <?php post_class(); ?>>
				<h1><?php the_title(); ?></h1>
				<div><?php the_content(); ?></div>
			</article>
		<?php endwhile; ?>
	<?php endif; ?>
</main>
<?php
get_footer();
